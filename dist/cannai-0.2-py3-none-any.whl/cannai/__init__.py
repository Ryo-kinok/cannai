# Import the version number at the top level
from cannai.version import get_version, __version_info__
from cannai.cannai_class import *